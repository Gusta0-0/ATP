using System;

class Program {
  public static void Main (string[] args) {

    char resposta;
    double media = 0;

  do{  Console.WriteLine ("Conferir a media do aluno (s para conferir / qualquer outro para sair)"); 
    resposta = char.Parse(Console.ReadLine());

    if (resposta == 's'){
      Console.WriteLine("Digite a media do aluno: ");
      media = double.Parse(Console.ReadLine());
      conceito(media);
    }
    }while(resposta == 's');
    Console.WriteLine("Programa encerrou");
  }

  static void conceito(double media){

    if(media <= 39){
      Console.WriteLine("F");
    }
    else if (media > 39 && media <= 59){
      Console.WriteLine("E");
    }
    else if (media > 59 && media <= 69){
      Console.WriteLine("D");
    }
    else if (media > 69 && media <= 79){
      Console.WriteLine("C");
    }
    else if (media > 79 && media <= 89){
      Console.WriteLine("B");
    }
    else {
      Console.WriteLine("A");
    }

  }
}