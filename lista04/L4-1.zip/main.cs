using System;

class Program {
  public static void Main (string[] args) {

    Console.WriteLine ("Quantos alunos terão a nota calculada? ");
    int nA = int.Parse(Console.ReadLine());

    if (nA > 0) {
      for(int i = 1; i <= nA; i++){
        media(i);
      }
    }
  }

static void media(int aluno){
  
  double med = 0;

  Console.WriteLine("Escreva as notas do aluno" + aluno);
  double x = double.Parse(Console.ReadLine());
  double y = double.Parse(Console.ReadLine());
  double z = double.Parse(Console.ReadLine());

  Console.WriteLine("Escolha uma opção: "); 
  Console.WriteLine("A - Média Aritmética");
  Console.WriteLine("P - Média Ponderada");	

  char resp = char.Parse(Console.ReadLine());

  if (resp == 'A') {
  med = (x + y + z)/3;
  }

  else if (resp == 'P'){
  med = (x*5 + y*3 + z*2)/10;
  }

    else {
    Console.WriteLine("Opção inválida");
    }

    Console.WriteLine("A média do aluno é: " + med);
  }
}
