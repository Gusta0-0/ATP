using System;

class Program {
  public static void Main (string[] args) {

    double form;

    Console.WriteLine ("Informe um valor de n (inteiro e positivo)");

    int n = int.Parse(Console.ReadLine());

    form = formula(n);

    Console.WriteLine("O valor da formula é: " + form);

  }

  static double formula (double n){

    double s = 0;

    for(int i = 1; i <= n; i++){
    s = Math.Pow(n, 2) / (n + 3);
  }
    return s;
  }

  }