using System;

class Program {
  public static void Main (string[] args) {

    int x;
    int y;
    int z;

    Console.WriteLine ("Digite quantos triangulos pretende verificar: ");
    int n = int.Parse(Console.ReadLine());


    for (int i = 0; i <= n; i++){
      Console.WriteLine("Digite os lados do triangulo");
      x = int.Parse(Console.ReadLine());
      y = int.Parse(Console.ReadLine());
      z = int.Parse(Console.ReadLine());
      verificador(x, y, z);

    }
  }

  static void verificador(int x, int y, int z){


    if (x < (y + z) && y < (x + z) &&  z < (y + x)){
      Console.WriteLine("É um triangulo");
      if (x == y && y == z){
        Console.WriteLine("Equilatero");
      }
      else if (x == y || y == z || x == z){
        Console.WriteLine("Isosceles");
      }
      else{
        Console.WriteLine("Escaleno");
      }
    } else {
    Console.WriteLine("Não é um triangulo");}
  }
}