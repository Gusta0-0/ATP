using System;

class Program {
  public static void Main (string[] args) {

    Console.WriteLine ("Quantos conjuntos você vai digitar? ");
    int c = int.Parse(Console.ReadLine());

    for (int i = 0; i <= c; i++){
      Console.WriteLine("Digite o conjunto de 3 numeros: ");
      int x = int.Parse(Console.ReadLine());
      int y = int.Parse(Console.ReadLine());
      int z = int.Parse(Console.ReadLine());

      ordem(x, y, z);
    }

  }

  static void ordem(int x, int y, int z){



    int maior = Math.Max(x, (Math.Max(y,z)));
    int menor = Math.Min(x, (Math.Min(y,z)));
    int medio = x + y + z - maior - menor;
    Console.WriteLine("A ordem: {0} {1} {2}", maior, medio, menor);
  }
}