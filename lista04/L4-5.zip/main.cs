using System;

class Program {
  public static void Main (string[] args) {

    int result;

    Console.WriteLine ("Digite dois numeros inteiros diferentes de 0");
    int n1 = int.Parse(Console.ReadLine());
    int n2 = int.Parse(Console.ReadLine());
    result = MDC(n1,n2);

    Console.WriteLine("O MDC é {0}", result);
  }

  static int MDC(int a, int b){

    int i;

    if (a>b){
      int aux = a;
      a = b;
      b = aux;
    }

    for (i = a; i>=1 && (i%a==0 && i%b==0); i--);
    return i;
  }
}