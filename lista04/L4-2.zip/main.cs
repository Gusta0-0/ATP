using System;

class Program {
  public static void Main (string[] args) {

    int pessoas = 0;

    Console.WriteLine ("Responder pesquisa? (s/n)");
    char resposta = char.Parse(Console.ReadLine());

    do {
      if (resposta == 's'){
      pesquisa(pessoas);

      Console.WriteLine ("Responder pesquisa? (s/n)");
      resposta = char.Parse(Console.ReadLine());
      }

    } while (resposta == 's'); 

    Console.WriteLine("Encerrou a pesquisa");
  }

  static void pesquisa(int pessoas){

    pessoas = pessoas + 1;

    Console.WriteLine("Quantos filhos possui? ");
    int filhos = int.Parse(Console.ReadLine());

    Console.WriteLine("Quanto recebe de salário?");
    double salario = double.Parse(Console.ReadLine()); 

    double mediaSalario = salario/pessoas;
    int mediaFilhos = filhos/pessoas;

    Console.WriteLine("A média de salário até agora é de: " + mediaSalario);

    Console.WriteLine("A média de filhos até agora é de: " + mediaFilhos); 

  }
}

