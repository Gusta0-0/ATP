using System;

class Program {
  public static void Main (string[] args) {

    int turma = 0;
    double aprovadoM = 0;

    Console.WriteLine ("Quantos alunos na turma?");
    turma = int.Parse(Console.ReadLine());

    for(int i = 1; i <= turma; i++){
      Console.WriteLine("Qual a nota do aluno " + i);
      int notas = int.Parse(Console.ReadLine());

      aprovadoM = aprovados(notas);
    }

    Console.WriteLine("A media das notas dos alunos aprovados é " + aprovadoM);
}

  static double aprovados(double notas){

    int aprovados = 0;
    double media;
    double notastotais = 0;


    if(notas >= 6){
      aprovados++;
      notastotais =+ notas;
    }    

    media = notastotais/aprovados;
    return media;



  }
}