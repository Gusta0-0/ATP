using System;

class Program {
  public static void Main (string[] args) {

    char resposta;
    int n;
    bool resultado;

    do {
      Console.WriteLine("Verificar se o numero e positivo ou negativo? (s/qualquer tecla para sair)");
      resposta = char.Parse(Console.ReadLine());

      if (resposta=='s')
      {

      Console.WriteLine("Digite um numero inteiro: ");
      n = int.Parse(Console.ReadLine());

      resultado = verificador(n);

      if (resultado == true)
        {
        Console.WriteLine("Positivo");
      } 

        else {Console.WriteLine("Negativo");}  
      }
    }while(resposta=='s');
  }

  static bool verificador(int n){

    bool positivo = true;
    bool negativo = false;

    if (n >0){
      return positivo;
    }
    return negativo;
  }
}