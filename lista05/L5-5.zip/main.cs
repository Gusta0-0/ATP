using System;

namespace SorteioNumeros
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numerosSorteados = SortearNumeros();

            int tentativa;

            do
            {
                Console.WriteLine("Informe uma tentativa: ");
                tentativa = int.Parse(Console.ReadLine());
            } while (!VerificarTentativa(numerosSorteados, tentativa));

       
            Console.WriteLine("Parabéns! Você acertou um número sorteado.");
        }

        static int[] SortearNumeros()
        {
            Random random = new Random();
            int[] numerosSorteados = new int[3];

            for (int i = 0; i < numerosSorteados.Length; i++)
            {
                numerosSorteados[i] = random.Next(10, 51);
            }

            return numerosSorteados;
        }

        static bool VerificarTentativa(int[] numerosSorteados, int tentativa)
        {
            for (int i = 0; i < numerosSorteados.Length; i++)
            {
                if (numerosSorteados[i] == tentativa)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
