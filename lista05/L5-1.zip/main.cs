using System;

class Program {
  public static void Main (string[] args) {
    

    Console.WriteLine ("Digite 20 números");
    int[] vetor = new int[20];
    
    for(int i = 0; i < 20; i++){
      Console.WriteLine("Numero: ");
      vetor[i] = int.Parse(Console.ReadLine());
    }
    menorNumero(vetor);
  }

  static void menorNumero(int[] vetor){
   
    int menor = vetor[0];
    int posicao = 0;

    for (int i = 1; i<vetor.Length; i++){
      if (vetor[i] < menor){
        menor = vetor[i];
        posicao = i;
      }
    }
    Console.WriteLine("O menor numero é {0} e sua posição é {1}", menor, posicao);
  }
}