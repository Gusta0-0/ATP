using System;

class Program
{
    static void Main()
    {
        int[,] matriz = PreencherMatriz();
        ExibirMatriz(matriz);

        TrocarLinha2ComLinha8(matriz);
        ExibirMatriz(matriz);

        TrocarColuna4ComColuna10(matriz);
        ExibirMatriz(matriz);

        TrocarDiagonalPrincipalComSecundaria(matriz);
        ExibirMatriz(matriz);

        TrocarLinha5ComColuna10(matriz);
        ExibirMatriz(matriz);
    }

    static int[,] PreencherMatriz()
    {
        int[,] M = new int[10, 10];
        int valor = 1;
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                M[i, j] = valor++;
            }
        }
        return M;
    }

    static void ExibirMatriz(int[,] M)
    {
        for (int i = 0; i < M.GetLength(0); i++)
        {
            for (int j = 0; j < M.GetLength(1); j++)
            {
                Console.Write(M[i, j].ToString("D3") + " ");
            }
            Console.WriteLine();
        }
        Console.WriteLine();
    }

    static void TrocarLinha2ComLinha8(int[,] M)
    {
        for (int j = 0; j < M.GetLength(1); j++)
        {
            int temp = M[1, j];
            M[1, j] = M[7, j];
            M[7, j] = temp;
        }
        Console.WriteLine("Após trocar a linha 2 com a linha 8:");
    }

    static void TrocarColuna4ComColuna10(int[,] M)
    {
        for (int i = 0; i < M.GetLength(0); i++)
        {
            int temp = M[i, 3];
            M[i, 3] = M[i, 9];
            M[i, 9] = temp;
        }
        Console.WriteLine("Após trocar a coluna 4 com a coluna 10:");
    }

    static void TrocarDiagonalPrincipalComSecundaria(int[,] M)
    {
        int n = M.GetLength(0);
        for (int i = 0; i < n; i++)
        {
            int temp = M[i, i];
            M[i, i] = M[i, n - 1 - i];
            M[i, n - 1 - i] = temp;
        }
        Console.WriteLine("Após trocar a diagonal principal com a diagonal secundária:");
    }

    static void TrocarLinha5ComColuna10(int[,] M)
    {
        int[] temp = new int[M.GetLength(1)];
        for (int j = 0; j < M.GetLength(1); j++)
        {
            temp[j] = M[4, j];
        }
        for (int i = 0; i < M.GetLength(0); i++)
        {
            M[4, i] = M[i, 9];
            M[i, 9] = temp[i];
        }
        Console.WriteLine("Após trocar a linha 5 com a coluna 10:");