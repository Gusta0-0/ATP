using System;

namespace VetoresIntercalados
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] x = new int[10];
            int[] y = new int[10];
            int[] z;

            PreencherVetores(x, y);

            z = IntercalarVetores(x, y);

            ExibirVetor(z);
        }
        static void PreencherVetores(int[] x, int[] y)
        {
            for (int i = 0; i < x.Length; i++)
            {
                Console.WriteLine("Informe o valor do elemento {0} do vetor x: ", i + 1);
                x[i] = int.Parse(Console.ReadLine());

                Console.WriteLine("Informe o valor do elemento {0} do vetor y: ", i + 1);
                y[i] = int.Parse(Console.ReadLine());
            }
        }

        static int[] IntercalarVetores(int[] x, int[] y)
        {
            int[] z = new int[x.Length + y.Length];
            int indiceVetorZ = 0;

            for (int i = 0; i < x.Length; i++)
            {
                z[indiceVetorZ] = x[i];
                indiceVetorZ += 2;
            }

            indiceVetorZ = 1;

            for (int i = 0; i < y.Length; i++)
            {
                z[indiceVetorZ] = y[i];
                indiceVetorZ += 2;
            }

            return z;
        }

        static void ExibirVetor(int[] vetor)
        {
            Console.WriteLine("Valores do vetor:");

            for (int i = 0; i < vetor.Length; i++)
            {
                Console.WriteLine(vetor[i]);
            }
        }
    }
}
