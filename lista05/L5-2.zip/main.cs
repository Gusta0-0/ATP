using System;

namespace MediaTurma
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] notas = new double[10];
            double mediaTurma;
            int alunosAcimaMedia;
          
            PreencherNotas(notas);
          
            CalcularMediaEContarAcimaMedia(notas, out mediaTurma, out alunosAcimaMedia);
            Console.WriteLine("Média da turma: {0}", mediaTurma);
            Console.WriteLine("Número de alunos acima da média: {0}", alunosAcimaMedia);
        }

        static void PreencherNotas(double[] notas)
        {
      
            for (int i = 0; i < notas.Length; i++)
            {
                Console.WriteLine("Informe a nota do aluno {0}: ", i + 1);
                notas[i] = double.Parse(Console.ReadLine());
            }
        }

        static void CalcularMediaEContarAcimaMedia(double[] notas, out double mediaTurma, out int alunosAcimaMedia)
        {
            mediaTurma = 0;
            alunosAcimaMedia = 0;

            for (int i = 0; i < notas.Length; i++)
            {
                mediaTurma += notas[i];

                if (notas[i] > mediaTurma)
                {
                    alunosAcimaMedia++;
                }
            }
            mediaTurma /= notas.Length;
        }
    }
}
