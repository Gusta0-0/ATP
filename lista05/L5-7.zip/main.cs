using System;

namespace Matrizes
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matriz = new int[5, 5];


            PreencherMatriz(matriz);

            int somaLinha4 = SomarLinha(matriz, 4);
            int somaColuna2 = SomarColuna(matriz, 2);
            int somaDiagonalPrincipal = SomarDiagonalPrincipal(matriz);
            int somaDiagonalSecundaria = SomarDiagonalSecundaria(matriz);
            int somaTodosElementos = SomarTodosElementos(matriz);

            Console.WriteLine("Soma da linha 4: {0}", somaLinha4);
            Console.WriteLine("Soma da coluna 2: {0}", somaColuna2);
            Console.WriteLine("Soma da diagonal principal: {0}", somaDiagonalPrincipal);
            Console.WriteLine("Soma da diagonal secundária: {0}", somaDiagonalSecundaria);
            Console.WriteLine("Soma de todos os elementos: {0}", somaTodosElementos);
        }
        static void PreencherMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.WriteLine("Informe o valor da posição ({0}, {1}): ", i, j);
                    matriz[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }
        static int SomarLinha(int[,] matriz, int linha)
        {
            int soma = 0;

            for (int i = 0; i < matriz.GetLength(1); i++)
            {
                soma += matriz[linha, i];
            }

            return soma;
        }

        static int SomarColuna(int[,] matriz, int coluna)
        {
            int soma = 0;

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                soma += matriz[i, coluna];
            }

            return soma;
        }

        static int SomarDiagonalPrincipal(int[,] matriz)
        {
            int soma = 0;

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                soma += matriz[i, i];
            }

            return soma;
        }

        static int SomarDiagonalSecundaria(int[,] matriz)
        {
            int soma = 0;

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                soma += matriz[i, matriz.GetLength(1) - 1 - i];
            }

            return soma;
        }

        static int SomarTodosElementos(int[,] matriz)
        {
            int soma = 0;

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    soma += matriz[i, j];
                }
            }

            return soma;
        }
    }
}
