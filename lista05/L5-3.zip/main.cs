using System;

namespace VetoresComValoresNegativos
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] x = new int[10];
            int[] y;

            PreencherVetor(x);
          
            y = CopiarValoresNegativos(x);
          
            ExibirVetor(y);
        }

        static void PreencherVetor(int[] vetor)
        {
            for (int i = 0; i < vetor.Length; i++)
            {
                Console.WriteLine("Informe o valor do elemento {0}: ", i + 1);
                vetor[i] = int.Parse(Console.ReadLine());
            }
        }

        static int[] CopiarValoresNegativos(int[] vetor)
        {
            int[] vetorNegativos = new int[vetor.Length];
            int indiceVetorNegativos = 0;

            for (int i = 0; i < vetor.Length; i++)
            {
                if (vetor[i] < 0)
                {
                    vetorNegativos[indiceVetorNegativos] = vetor[i];
                    indiceVetorNegativos++;
                }
            }
            return vetorNegativos;
        }
        static void ExibirVetor(int[] vetor)
        {
            Console.WriteLine("Valores do vetor:");

            for (int i = 0; i < vetor.Length; i++)
            {
                Console.WriteLine(vetor[i]);
            }
        }
    }
}
