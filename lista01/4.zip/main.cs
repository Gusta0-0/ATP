using System;

class Program {
  public static void Main (string[] args)
  {
    double x1, y1, x2, y2, distancia;

    Console.WriteLine("Digite o x1");
    x1 = double.Parse(Console.ReadLine());
    Console.WriteLine("digite y1");
    y1 = double.Parse(Console.ReadLine());
    Console.WriteLine("digite o x2");
    x2 = double.Parse(Console.ReadLine());
    Console.WriteLine("digite o y2");
    y2 = double.Parse(Console.ReadLine());

   distancia = Math.Sqrt(Math.Pow(x2 - x1,2) + Math.Pow(y2- y1,2));

    Console.WriteLine("distancia entre os pontos: " + distancia);
    

    
  }
}