using System;

class Program
{
    public static void Main(string[] args)
    {
        double aplicacaoM, taxa, rendimento;
        double Nmeses;

        Console.WriteLine(" Digite a aplicaçao mensal: ");
        aplicacaoM = double.Parse(Console.ReadLine());
        Console.WriteLine("Digite a taxa: ");
        taxa = double.Parse(Console.ReadLine());
        Console.WriteLine(" Digite o numero de meses: ");
        Nmeses = double.Parse(Console.ReadLine());

        rendimento = aplicacaoM * (Math.Pow(1 + taxa, Nmeses) - 1) / taxa;

        Console.WriteLine("Rendimento: " + rendimento);
    }
}