using System;

class Program {
  public static void Main (string[] args) 
  {

    Console.WriteLine ("Digite a Conta: ");
    int conta = int.Parse(Console.ReadLine());

    if (conta < 1000 && conta > 99) {


    int C = (conta / 100);
    int D = (conta % 100)/10;
    int U = (conta % 10);


    int inverso = (U*100)+(D*10)+C;

    int resultado1 = conta + inverso;
    int verificador = resultado1 % 10;
      if (resultado1 < 1000){
      int C2 = (resultado1 / 100);
      int D2 = (resultado1 % 100)/10;
      int U2 = (resultado1 % 10);
        
      int multiplicacao = (C2 * 1) + (D2 * 2) + (U2 * 3); 

      int U3 = (multiplicacao % 10);
      
    Console.WriteLine(" A soma é: " + resultado1);
    Console.WriteLine(" A soma das multiplicações é:  " + multiplicacao);
    Console.WriteLine(" O digito verificador é: " + U3);
      }
      else{
        int C2 = (resultado1 / 100) % 10;
        int D2 = (resultado1 % 100)/10;
          int U2 = (resultado1 % 10);

          int multiplicacao = (C2 * 1) + (D2 * 2) + (U2 * 3); 

          int U3 = (multiplicacao % 10);

        Console.WriteLine(" A soma é: " + resultado1);
        Console.WriteLine(" A soma das multiplicações é:  " + multiplicacao);
        Console.WriteLine(" O digito verificador é: " + U3);
      }
      }
    else {
      Console.WriteLine("Conta inválida");
    }  
  }
}