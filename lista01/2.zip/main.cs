using System;

class Program {
  public static void Main () {
    
    double cateto1, cateto2, hipotenusa;
    
    Console.WriteLine("digite um cateto");
    cateto1 = double.Parse(Console.ReadLine());
    Console.WriteLine("digite o outro cateto");
    cateto2 = double.Parse(Console.ReadLine());

    hipotenusa = Math.Sqrt(Math.Pow(cateto1,2) + Math.Pow(cateto2,2));

    Console.WriteLine("hipotenusa: " + hipotenusa);
 
    
    
    
    
    
    
    
    
    }
}