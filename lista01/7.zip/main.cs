using System;

class Program {
  public static void Main (string[] args) 
  {
    int dias2, meses, anos;

    Console.WriteLine("Digite dias sem acidentes");
    int dias = int.Parse(Console.ReadLine());

    anos = dias/365;
    meses = (dias % 365) / 30;
    dias2 = (dias % 365) % 30;

    Console.WriteLine("Anos: " + anos + " Meses: " + meses + " Dias: " + dias2);







    
  }
}