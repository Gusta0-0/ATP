using System;

class Program {
  public static void Main (string[] args)
  {
    double a, b, aux;

    Console.WriteLine ("Digite um numero");
    a = double.Parse(Console.ReadLine());
    Console.WriteLine ("Digite outro numero");
    b = double.Parse(Console.ReadLine());

    aux = a;
    a = b;
    b = aux;

    Console.WriteLine ("O valor de A é: "+ a);
    Console.WriteLine ("O valor de B é: "+ b);


  }
}