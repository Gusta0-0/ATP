using System;

class Program 
{
  public static void Main () 
  {
    double sm, kw, valor, desconto, valorUnitario;
    
    Console.WriteLine ("Digite o salario minimo");
    sm = double.Parse(Console.ReadLine());
    Console.WriteLine ("Digite o quilowatts");
    kw = double.Parse(Console.ReadLine());

    valor = (sm/7) * (kw/100);
    valorUnitario = valor/kw;
    desconto = valor* 0.9;

    Console.WriteLine ("valor de cada quilowatts: " + valorUnitario);
    Console.WriteLine ("valor a ser pago: " + valor);
    Console.WriteLine ("valor com desconto: " + desconto);
  
    
    
    
    }
}