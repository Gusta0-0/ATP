using System;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Ano de nascimento:");
        int anoNascimento = int.Parse(Console.ReadLine());
        int anoAtual = DateTime.Now.Year;
        Console.WriteLine("Já fez aniversário este ano? (s/n)");
        string respostaAniversario = Console.ReadLine().ToUpper(); 
        int idade;
        if (respostaAniversario == "S")
        {
            idade = anoAtual - anoNascimento;
        }
        else
        {
            idade = anoAtual - anoNascimento - 1;
        }

        Console.WriteLine($"Idade: {idade} anos");

        if (idade >= 18)
        {
            Console.WriteLine("Você já pode obter a Carteira de Habilitação!");
        }
        else
        {
            Console.WriteLine("Você ainda não tem idade para obter a Carteira de Habilitação.");
        }
    }
}