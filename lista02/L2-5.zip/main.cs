using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Digite sua nota: ");
    double nota = double.Parse(Console.ReadLine());
    if (nota > 10) {
      Console.WriteLine("inválido");
    }
    else if (nota >= 8) {
      Console.WriteLine("Ótimo");
    }
    else if (nota >= 7) {
      Console.WriteLine("Bom");
    }
    else if (nota >= 5) {
      Console.WriteLine("Regular");
    }
    else if (nota < 5) {
      Console.WriteLine("Insatisfatório");
    }
    else {
      Console.WriteLine("inválido");
    }
  }
}