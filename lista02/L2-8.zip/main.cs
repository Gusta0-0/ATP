using System;

class Program {
  public static void Main (string[] args) {

    double salario = 0;

    do {
    Console.WriteLine("Digite o salário do funcionário: ");
    salario = double.Parse(Console.ReadLine());
    } while (salario<0);

    Console.WriteLine("Escolha uma opção: \n A - Aumento 8% \n B - Aumento 11% \n C - Aumento fixo");
    char opcao = char.Parse(Console.ReadLine().ToUpper());

    double novoSalario = 0;;

    switch (opcao){
    case 'A': 
      novoSalario = salario * 1.08;
      break;

    case 'B':
      novoSalario = salario * 1.11;
      break;

    case 'C': 
      if (salario<=1000){
        novoSalario = salario + 350;
      }
      else {
        novoSalario = salario + 200;
      }
      break;

      default: Console.WriteLine("erro");
      break;
    }

    Console.WriteLine("Novo salário: R$" + novoSalario);
  }
}