using System;

class Program {
  public static void Main (string[] args) {

    Console.WriteLine ("Digite a velocidade máxima permitida na avenida:");
    double VM = double.Parse(Console.ReadLine());

    Console.WriteLine ("Digite a velocidade do motorista:");
    double motorista = double.Parse(Console.ReadLine());


if (motorista <= VM) {
  Console.WriteLine("Motorista respeitou a lei");
}
    else if (motorista > VM && motorista <= VM + 10){
      Console.WriteLine("Motorista recebeu uma multa de R$50,00");
    }

    else if (motorista > VM + 10 && motorista <= VM + 30){
      Console.WriteLine("Motorista recebeu uma multa de R$100,00");
    }
    else {
      Console.WriteLine("Motorista recebeu uma multa de DUZENTOSS");
    }
  }
}