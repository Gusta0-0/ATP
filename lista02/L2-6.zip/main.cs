using System;

class Program {
  public static void Main (string[] args) {
    double a = 75;
    double p = 0.75;

    Console.WriteLine("Inira a diária:");
    double d = double.Parse(Console.ReadLine());

    double dPromo = d*p;
    double vA80 = (a*0.8)*dPromo;
    double vA50 = (a/2)*d;
    double dif = (vA80 - vA50);

    Console.WriteLine("Diária Promocional = " + dPromo);
    Console.WriteLine("Promoção com 80% = " + vA80);
    Console.WriteLine("Diária sem a promoção com 50% = " + vA50);
    Console.WriteLine("A diferença é" + dif);
  }
}