using System;
using System.IO;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.Write("Digite um número: ");
        int numero;
        while (!int.TryParse(Console.ReadLine(), out numero) || numero <= 0)
        {
            Console.Write("Entrada inválida. Por favor, digite um número inteiro positivo: ");
        }

        List<int> divisores = ObterDivisores(numero);
        Console.WriteLine("Divisores de " + numero + ": " + string.Join(", ", divisores));

        int somaDivisores = SomarDivisores(divisores);

        string caminhoArquivo = "soma_divisores.txt";
        try
        {
            File.WriteAllText(caminhoArquivo, "Soma dos divisores de " + numero + ": " + somaDivisores);
            Console.WriteLine("A soma dos divisores foi salva no arquivo: " + caminhoArquivo);
        }
        catch (Exception e)
        {
            Console.WriteLine("Ocorreu um erro ao salvar a soma dos divisores: " + e.Message);
        }
    }

    static List<int> ObterDivisores(int numero)
    {
        List<int> divisores = new List<int>();
        for (int i = 1; i <= numero; i++)
        {
            if (numero % i == 0)
            {
                divisores.Add(i);
            }
        }
        return divisores;
    }

    static int SomarDivisores(List<int> divisores)
    {
        int soma = 0;
        foreach (int divisor in divisores)
        {
            soma += divisor;
        }
        return soma;
    }
}
