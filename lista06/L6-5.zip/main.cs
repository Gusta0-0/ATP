using System;
using System.IO;

class Program
{
    static void Main()
    {
        string caminhoArquivo = "caminho/do/arquivo.txt";

        try
        {
            string[] linhas = File.ReadAllLines(caminhoArquivo);
o
            foreach (string linha in linhas)
            {
                Console.WriteLine(linha);
            }

            Console.WriteLine($"\nQuantidade de linhas: {linhas.Length}");
        }
        catch (Exception e)
        {
            Console.WriteLine("Ocorreu um erro ao ler o arquivo: " + e.Message);
        }
    }
}
