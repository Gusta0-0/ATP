using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.Write("Digite a quantidade de letras que deseja inserir: ");
        int quantidadeLetras;
        while (!int.TryParse(Console.ReadLine(), out quantidadeLetras) || quantidadeLetras <= 0)
        {
            Console.Write("Entrada inválida. Por favor, digite um número inteiro positivo: ");
        }

        char[] letras = new char[quantidadeLetras];


        for (int i = 0; i < quantidadeLetras; i++)
        {
            Console.Write($"Digite a letra {i + 1}: ");
            letras[i] = Console.ReadLine()[0];
        }


        string caminhoArquivo = "letras.txt";

        try
        {
            File.WriteAllText(caminhoArquivo, new string(letras));
            Console.WriteLine("As letras foram salvas no arquivo: " + caminhoArquivo);
        }
        catch (Exception e)
        {
            Console.WriteLine("Ocorreu um erro ao salvar as letras no arquivo: " + e.Message);
            return;
        }

        string conteudo;
        try
        {
            conteudo = File.ReadAllText(caminhoArquivo);
        }
        catch (Exception e)
        {
            Console.WriteLine("Ocorreu um erro ao ler o arquivo: " + e.Message);
            return;
        }

        int quantidadeVogais = conteudo.Count(c => "aeiouAEIOU".Contains(c));


        Console.WriteLine("Quantidade de vogais no arquivo: " + quantidadeVogais);
    }
}
