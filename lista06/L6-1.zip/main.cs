using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite uma frase: ");
        string frase = Console.ReadLine();

     
        int numEspacos = ContarEspacosEmBranco(frase);

       
        Console.WriteLine($"A frase contém {numEspacos} espaços em branco.");
    }

   
    static int ContarEspacosEmBranco(string frase)
    {
        int contador = 0;
        foreach (char c in frase)
        {
            if (c == ' ')
            {
                contador++;
            }
        }
        return contador;
    }
}
