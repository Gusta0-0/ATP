using System;
using System.IO;

class Program
{
    static void Main()
    {
        string caminhoArquivo = "caminho/do/arquivo.txt";

        try
        {o
            string conteudo = File.ReadAllText(caminhoArquivo);

            int quantidadeA = ContarCaracteresA(conteudo);

            Console.WriteLine($"A quantidade de caracteres 'a' e 'A' no arquivo é: {quantidadeA}");
        }
        catch (Exception e)
        {

            Console.WriteLine("Ocorreu um erro ao ler o arquivo: " + e.Message);
        }
    }

    
    static int ContarCaracteresA(string texto)
    {
        int contador = 0;

        foreach (char c in texto)
        {
            if (c == 'a' || c == 'A')
            {
                contador++;
            }
        }

        return contador;
    }
}
