using System;
using System.IO;
using System.Globalization; // Para usar ponto como separador decimal na conversão

class Program
{
    static void Main()
    {
        string caminhoArquivo = "numeros.txt"; // Nome do arquivo onde estão os números

        // Verifica se o arquivo existe
        if (!File.Exists(caminhoArquivo))
        {
            Console.WriteLine("Arquivo não encontrado: " + caminhoArquivo);
            return;
        }

        // Declara variáveis para armazenar os valores máximo, mínimo e a soma para calcular a média
        double maximo = double.MinValue;
        double minimo = double.MaxValue;
        double soma = 0;
        int contador = 0;

        // Lê as linhas do arquivo e processa cada número
        using (StreamReader reader = new StreamReader(caminhoArquivo))
        {
            string linha;
            while ((linha = reader.ReadLine()) != null)
            {
                // Converte a linha para double
                if (double.TryParse(linha, NumberStyles.Float, CultureInfo.InvariantCulture, out double numero))
                {
                    // Atualiza o máximo e o mínimo
                    if (numero > maximo)
                    {
                        maximo = numero;
                    }
                    if (numero < minimo)
                    {
                        minimo = numero;
                    }

                    // Adiciona o número à soma para calcular a média
                    soma += numero;
                    contador++;
                }
                else
                {
                    Console.WriteLine($"Ignorando valor inválido na linha: {linha}");
                }
            }
        }

        // Calcula a média
        double media = contador > 0 ? soma / contador : 0;

        // Exibe os resultados na tela
        Console.WriteLine($"Valor máximo: {maximo}");
        Console.WriteLine($"Valor mínimo: {minimo}");
        Console.WriteLine($"Média: {media}");
    }
}
