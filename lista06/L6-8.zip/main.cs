using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.Write("Digite a quantidade de veículos: ");
        int quantidadeVeiculos;
        while (!int.TryParse(Console.ReadLine(), out quantidadeVeiculos) || quantidadeVeiculos <= 0)
        {
            Console.Write("Entrada inválida. Por favor, digite um número inteiro positivo: ");
        }

        Console.Write("Digite o valor do aluguel por veículo: ");
        decimal valorAluguel;
        while (!decimal.TryParse(Console.ReadLine(), out valorAluguel) || valorAluguel <= 0)
        {
            Console.Write("Entrada inválida. Por favor, digite um valor positivo: ");
        }


        decimal faturamentoMensal = (quantidadeVeiculos * valorAluguel) / 3;
        decimal faturamentoAnual = faturamentoMensal * 12;
        decimal valorMultasMensal = (faturamentoMensal / 10) * 0.2m;

        decimal valorManutencaoAnual = (quantidadeVeiculos * 0.02m) * 600;


        Console.WriteLine($"Faturamento mensal: R$ {faturamentoMensal:F2}");
        Console.WriteLine($"Faturamento anual: R$ {faturamentoAnual:F2}");
        Console.WriteLine($"Valor ganho com multas no mês: R$ {valorMultasMensal:F2}");
        Console.WriteLine($"Valor gasto com manutenção anual: R$ {valorManutencaoAnual:F2}");

  
        string caminhoArquivo = "resultado.txt";
        try
        {
            using (StreamWriter writer = new StreamWriter(caminhoArquivo))
            {
                writer.WriteLine($"Faturamento mensal: R$ {faturamentoMensal:F2}");
                writer.WriteLine($"Faturamento anual: R$ {faturamentoAnual:F2}");
                writer.WriteLine($"Valor ganho com multas no mês: R$ {valorMultasMensal:F2}");
                writer.WriteLine($"Valor gasto com manutenção anual: R$ {valorManutencaoAnual:F2}");
            }
            Console.WriteLine($"Os resultados foram salvos no arquivo: {caminhoArquivo}");
        }
        catch (Exception e)
        {
            Console.WriteLine("Ocorreu um erro ao salvar os resultados no arquivo: " + e.Message);
        }
    }
}
