using System;
using System.IO;

class Program
{
    static void Main()
    {
        string caminhoArquivo = "dados_alunos.txt";

        while (true)
        {
            Console.WriteLine("Escolha uma opção:");
            Console.WriteLine("1. Inserir dados de alunos");
            Console.WriteLine("2. Ler dados de alunos");
            Console.WriteLine("3. Sair");
            Console.Write("Opção: ");
            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    InserirDadosAlunos(caminhoArquivo);
                    break;
                case "2":
                    LerDadosAlunos(caminhoArquivo);
                    break;
                case "3":
                    return;
                default:
                    Console.WriteLine("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }

    static void InserirDadosAlunos(string caminhoArquivo)
    {
        using (StreamWriter writer = new StreamWriter(caminhoArquivo, true))
        {
            while (true)
            {
                Console.Write("Digite a matrícula do aluno (ou deixe em branco para terminar): ");
                string matricula = Console.ReadLine();
                if (string.IsNullOrEmpty(matricula))
                {
                    break;
                }

                Console.Write("Digite o telefone do aluno: ");
                string telefone = Console.ReadLine();

                writer.WriteLine($"{matricula},{telefone}");
            }
        }

        Console.WriteLine("Dados dos alunos foram salvos com sucesso.\n");
    }

    static void LerDadosAlunos(string caminhoArquivo)
    {
        if (!File.Exists(caminhoArquivo))
        {
            Console.WriteLine("O arquivo de dados dos alunos não existe.\n");
            return;
        }

        using (StreamReader reader = new StreamReader(caminhoArquivo))
        {
            string linha;
            while ((linha = reader.ReadLine()) != null)
            {
                string[] dados = linha.Split(',');
                Console.WriteLine($"Matrícula: {dados[0]}, Telefone: {dados[1]}");
            }
        }

        Console.WriteLine();
    }
}
