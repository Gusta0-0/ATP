using System;

class Program
{
    static void Main()
    {
        // Solicita uma string do usuário
        Console.Write("Digite uma string: ");
        string entrada = Console.ReadLine();

        // Codifica a string usando o Código de César
        string codificada = CodificarCesar(entrada, 3);

        // Exibe a string codificada
        Console.WriteLine("String codificada: " + codificada);
    }

    // Função para codificar uma string usando o Código de César
    static string CodificarCesar(string texto, int deslocamento)
    {
        string resultado = string.Empty;

        foreach (char c in texto)
        {
            if (char.IsLetter(c))
            {
                char offset = char.IsUpper(c) ? 'A' : 'a';
                char codificado = (char)(((c + deslocamento - offset) % 26) + offset);
                resultado += codificado;
            }
            else
            {
                resultado += c;
            }
        }

        return resultado;
    }
}
