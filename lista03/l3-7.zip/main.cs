using System;

class Program {
  public static void Main (string[] args) {
    double n =0;
    double s =1;

    do {
      Console.WriteLine("Digite um número maior que zero");
      n = double.Parse(Console.ReadLine());
    } while (n < 0);

    for (int i = 1; i <= n; i++){
      s = s + 1/i;
      Console.WriteLine(s);
    }
    Console.WriteLine("O valor de S é: " + s);
  }
}