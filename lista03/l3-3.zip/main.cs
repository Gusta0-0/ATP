using System;

class Program {
  public static void Main (string[] args) {

    int numero = 0;
    int div3e9 = 0;
    int div2 =0;
    int div5 = 0;

    Console.WriteLine("Digite 10 numeros: ");

    for (int i = 0; i <= 10; i++){
      numero = int.Parse(Console.ReadLine());
      if (numero % 3 == 0 && numero % 9 == 0){
        div3e9++;
      }
      else if (numero % 2 == 0){
        div2++;
      }
      else if (numero % 5 ==0){
        div5++;
      }
      else {
        Console.WriteLine("Número não é divisivel pelos valores");
      }
    }
    Console.WriteLine("Quantidade de numeros divisiveis por 3 e 9: " + div3e9);
    Console.WriteLine("A quantidade de numeros divisiveis por 2: " + div2);
    Console.WriteLine("A quantidade de numeros divisiveis por 5: " + div5);
  }
}