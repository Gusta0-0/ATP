using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite um valor limite: ");
        int limite = int.Parse(Console.ReadLine());

        int a = 0;
        int b = 1;

        Console.WriteLine("\nValores da sequência de Fibonacci menores que " + limite + ":\n");


        Console.WriteLine(b);

        while (a + b < limite)
        {
            int auxiliar = a + b;
            a = b;
            b = auxiliar;


            Console.WriteLine(auxiliar);
        }
    }
}
