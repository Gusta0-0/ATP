using System;

class Program {
  public static void Main (string[] args) {

    int c1 =0;
    int c2 =0;
    int c3 =0;
    int c4 =0;

    int nulo =0;
    int branco =0;

    int voto =0;

    do {
      Console.WriteLine ("Vote 1 para candidato 1, 2 para candidato 2, 3 para candidato 3, 4 para candidato 4, 5 para nulo e 6 para branco");

    voto = int.Parse(Console.ReadLine());

      if (voto == 1){
        c1++;
      }

      else if (voto ==2){
        c2++;
      }

      else if (voto ==3){
        c3++;
      }

      else if (voto ==4){
        c4++;
      }

      else if (voto ==5){
        nulo++;
      }

      else if (voto ==6){
        branco++;
      }

      else {
        Console.WriteLine("Voto inválido. Digite outro");
      }

      } while (voto!=0);
    Console.WriteLine("Candidato 1: " + c1);
    Console.WriteLine("Candidato 2: " + c2);
    Console.WriteLine("Candidato 3: " + c3);
    Console.WriteLine("Candidato 4: " + c4);
    Console.WriteLine("Nulos: " + nulo);
    Console.WriteLine("Brancos: " + branco);


  }
}