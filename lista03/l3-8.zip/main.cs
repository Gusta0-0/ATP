using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite um número: ");
        int n = int.Parse(Console.ReadLine());

        int a = 0;
        int b = 1;

        Console.WriteLine("\nSérie de Fibonacci:\n");


        Console.WriteLine(b);

        for (int i = 0; i < n; i++)
        {
            int auxiliar = a + b;
            a = b;
            b = auxiliar;


            Console.WriteLine(auxiliar);
        }
    }
}
