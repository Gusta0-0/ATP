using System;

class Program
{
    static void Main(string[] args)
    {
       

        int positivos = 0;
        int negativos = 0;
        int zeros = 0;
        int num;
       string opcao;
        // contando positivos, negativos e zeros
  do {
    Console.WriteLine("Informe um numero: ");
    num = int.Parse(Console.ReadLine());
  

            if (num > 0)
            {
                positivos++;
            }
            else if (num < 0)
            {
                negativos++;
            }
            else
            {
                zeros++;
            }
        Console.WriteLine("Deseja infomar outro numero? (s/n)");
        opcao = Console.ReadLine();
       } while(opcao =="s" || opcao == "S");

      
        Console.WriteLine("Quantidade de números positivos: " + positivos);
        Console.WriteLine("Quantidade de números negativos: " + negativos);
        Console.WriteLine("Quantidade de zeros: " + zeros);
    }
}
