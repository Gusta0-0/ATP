using System;

class Program
{
    static void Main(string[] args)
    {


        int positivos = 0;
        int negativos = 0;
        int zeros = 0;
        int num;
        double PP = 0, PN = 0, PZ = 0;
       string opcao;
       double total = 0;
      
        // contando positivos, negativos e zeros
  do {
    Console.WriteLine("Informe um numero: ");
    num = int.Parse(Console.ReadLine());


            if (num > 0)
            {
                positivos++;
            }
            else if (num < 0)
            {
                negativos++;
            }
            else
            {
                zeros++;
            }
    total++;
        Console.WriteLine("Deseja infomar outro numero? (s/n)");
        opcao = Console.ReadLine();
       } while(opcao =="s" || opcao == "S");

      PP = (positivos/total)*100;
      PN = (negativos/total)*100;
      PZ = (zeros/total)*100;
      
        Console.WriteLine("Quantidade de números positivos: " + PP.ToString("F2"));
        Console.WriteLine("Quantidade de números negativos: " + negativos);
        Console.WriteLine("Quantidade de zeros: " + zeros);
    }
}
