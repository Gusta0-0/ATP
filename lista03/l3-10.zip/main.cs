using System;

class Program {
  public static void Main (string[] args) {

    double compras = 0;
    double pcompras = 0;
    double pvendas = 0;
    double vendas = 0;
    double lucro10 = 0;
    double lucro11 = 0;
    double lucro21 = 0;
    double lucrototal = 0;

    do {
      Console.WriteLine ("Digite o valor da compra ou 0 para encerrar. ");
      pcompras = double.Parse(Console.ReadLine());

      if (pcompras!=0){

        compras ++;

        Console.WriteLine("Digite o valor da venda. ");
        pvendas = double.Parse(Console.ReadLine());

        vendas ++;

        double conta = pcompras-pvendas;
        double lucro = conta/pcompras;
        double dez = pcompras*0.1;
        double vinte = pcompras*0.2;
        double lucroconta = 0;

        lucroconta = pvendas-pcompras;

        lucrototal = lucrototal+lucroconta;

        if (lucro <= dez){
          lucro10 ++;
        }
        else if (lucro > dez && lucro<= vinte){
          lucro11++;
        }
        else {
          lucro21++;
        }
      }

      } while (pcompras!=0);

    Console.WriteLine("Total de Compras: "+compras);
    Console.WriteLine("Total de vendas: "+vendas);
    Console.WriteLine("Vendas com lucro de 10%: "+lucro10);
    Console.WriteLine("Vendas com lucro de 10% a 20%: "+lucro11);
    Console.WriteLine("Vendas com lucro maior que 20%: "+lucro21);
    Console.WriteLine("Lucro total: " +lucrototal);
  }
}