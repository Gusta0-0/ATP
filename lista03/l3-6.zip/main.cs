using System;

class Program {
  public static void Main (string[] args) {

    double salario;
    int filhos = 0;
    int filhostotal = 0;
    double maiorsalario = 0;
    double salario100 = 0;
    double salariototal=0;
    int pessoas = 0;

    Console.WriteLine ("Digite o salário ou 0 para encerrar o levantamento: ");
    salario = double.Parse(Console.ReadLine());

    while (salario > 0) {

      salariototal = salariototal + salario;

      Console.WriteLine("Quantos filhos possui? ");
      filhos = int.Parse(Console.ReadLine());
      filhostotal = filhostotal + filhos;

      if (salario>maiorsalario){
        maiorsalario = salario;
      }

      if (salario<=100){
        salario100 ++;
      }
      pessoas++;

      Console.WriteLine ("Digite o salário ou 0 para encerrar o levantamento: ");
      salario = double.Parse(Console.ReadLine());
    }

    double mediasalario = salariototal/pessoas;
    double mediafilhos = filhostotal/pessoas;

    double percentual = (salario100/pessoas)*100;

    Console.WriteLine("A média do salário da população é: "+mediasalario);
    Console.WriteLine("A média do número de filhos é: "+mediafilhos);
    Console.WriteLine("O maior salário é: "+maiorsalario);
    Console.WriteLine("Percentual de pessoas com ate 100 reais de salário: "+percentual);


  }
}